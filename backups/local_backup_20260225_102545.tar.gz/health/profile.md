# Health Profile

## Personal Info
- **Name:** [Member Name]
- **DOB:** [Unknown]
- **Blood Type:** [Unknown - to collect]
- **Allergies:** [Unknown]
- **Insurance:** [Unknown]

## Medical History
[To be added]

## Current Medications
[None known]

## Emergency Contacts
- **Primary:** Ahie Juma

## 📝 Data Collection
Key info to collect through interactions:
- Blood type
- Known allergies  
- Insurance provider & policy number
- Current medications
- Doctor contacts

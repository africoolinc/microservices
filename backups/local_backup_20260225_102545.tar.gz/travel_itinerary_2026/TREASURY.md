# ✈️ Juma Family Travel Treasury
**Purpose**: Collect and manage USDC to cover travel and accommodation for Gibson's 2026 SasS Building Tour.

## 💳 Savings Wallet
- **Network**: Ethereum Mainnet / Arbitrum One
- **Address**: \`0x5aE436975c76721d9ab8ff0EF49Ce40fE0a0Bca0\`
- **Status**: **ACTIVE**

## 📊 Funding Status
| Target Event | Month | Est. Cost (USD) | Saved (USDC) | Status |
|--------------|-------|-----------------|--------------|--------|
| SXSW         | Mar   | $5,000          | $0.00        | 🔴 Unfunded |
| LEAP         | Apr   | $3,000          | $0.00        | 🔴 Unfunded |
| Black is Tech| Apr   | $5,000          | $0.00        | 🔴 Unfunded |

---
*Note: Contributions from family are welcomed here to secure Gibson's global SAS expansion.*

"""
E-Commerce Service - Main Entry Point
"""
from src.main import app

if __name__ == '__main__':
    import os
    port = int(os.getenv('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)
